Hi! This is the Paint Project Submission for ICS3U from James F!

The fonts folder is pretty much useless, I just used to to make the text for the guide page
in aseprite. it is not used at all in the code.

Also, title_oval.png and paley.png isn't being used at all, it was for making the title.png image.

The theme is a custom theme made by me, and the mascot is Poto the ghost!
Poto is a cross between a ghost and a drop of white paint, with the theme of the program.

I also didn't have the time to make an "unfilled line"... so hopefully I won't lose too many marks on that...

Enjoy the program!